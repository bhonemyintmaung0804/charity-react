import React from "react";
import '../css/NotFound.css';

const NotFound = () => {
    return (
        <div className="not-found"></div>
    )
}

export default NotFound;